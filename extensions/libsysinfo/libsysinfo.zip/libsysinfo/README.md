# libsysinfo

the crust is elusive when it cast forth to the child-like man

![Win32](https://github.com/time-killer-games/libsysinfo/raw/main/win32.png "Win32")

![macOS](https://github.com/time-killer-games/libsysinfo/raw/main/macos.png "macOS")

![Ubuntu](https://github.com/time-killer-games/libsysinfo/raw/main/ubuntu.png "Ubuntu")

![Deepin](https://github.com/time-killer-games/libsysinfo/raw/main/deepin.png "Deepin")
