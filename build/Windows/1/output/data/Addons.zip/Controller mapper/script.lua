---@diagnostic disable: lowercase-global

lana_node = "";  lana_valueKey = "";  lana_center = { 0, 0 };  lana_scale  = 1; lana_drag = false;
rana_node = "";  rana_valueKey = "";  rana_center = { 0, 0 };  rana_scale  = 1; rana_drag = false;

btx_node = "";  btx_valueKey = "";  btx_value_press = 1;  btx_value_unpress = 0;  btx_drag = false;
bty_node = "";  bty_valueKey = "";  bty_value_press = 1;  bty_value_unpress = 0;  bty_drag = false;
bta_node = "";  bta_valueKey = "";  bta_value_press = 1;  bta_value_unpress = 0;  bta_drag = false;
btb_node = "";  btb_valueKey = "";  btb_value_press = 1;  btb_value_unpress = 0;  btb_drag = false;

pdh_node = "";  pdh_valueKey = "";  pdh_value = { -1, 1 };  pdh_drag = false;
pdv_node = "";  pdv_valueKey = "";  pdv_value = { -1, 1 };  pdv_drag = false;

trl_node  = "";  trl_valueKey  = "";  trl_value_press  = 1;  trl_value_unpress  = 0;  trl_drag  = false;
trlb_node = "";  trlb_valueKey = "";  trlb_value_press = 1;  trlb_value_unpress = 0;  trlb_drag = false;
trr_node  = "";  trr_valueKey  = "";  trr_value_press  = 1;  trr_value_unpress  = 0;  trr_drag  = false;
trrb_node = "";  trrb_valueKey = "";  trrb_value_press = 1;  trrb_value_unpress = 0;  trrb_drag = false;

drag_sx = 0
drag_sy = 0

deadZone = 0
recording = true
record_loop = false

setting_page = 0;

function onEdit_lana_Center(i, cen) lana_center[i] = cen;   return true; end
function onEdit_lana_Scale(sca)     lana_scale = sca;       return true; end
function onEdit_rana_Center(i, cen) rana_center[i] = cen;   return true; end
function onEdit_rana_Scale(sca)     rana_scale = sca;       return true; end

function onEdit_btx_value_press(val)   btx_value_press = val;     return true; end
function onEdit_bty_value_press(val)   bty_value_press = val;     return true; end
function onEdit_bta_value_press(val)   bta_value_press = val;     return true; end
function onEdit_btb_value_press(val)   btb_value_press = val;     return true; end

function onEdit_btx_value_unpress(val)   btx_value_unpress = val;     return true; end
function onEdit_bty_value_unpress(val)   bty_value_unpress = val;     return true; end
function onEdit_bta_value_unpress(val)   bta_value_unpress = val;     return true; end
function onEdit_btb_value_unpress(val)   btb_value_unpress = val;     return true; end

function onEdit_pdh_value(i, val)   pdh_value[i] = val;     return true; end
function onEdit_pdv_value(i, val)   pdv_value[i] = val;     return true; end

function onEdit_trl_value_press(val)   trl_value_press = val;     return true; end
function onEdit_trlb_value_press(val)  trlb_value_press = val;    return true; end
function onEdit_trr_value_press(val)   trr_value_press = val;     return true; end
function onEdit_trrb_value_press(val)  trrb_value_press = val;    return true; end

function onEdit_trl_value_unpress(val)   trl_value_unpress = val;     return true; end
function onEdit_trlb_value_unpress(val)  trlb_value_unpress = val;    return true; end
function onEdit_trr_value_unpress(val)   trr_value_unpress = val;     return true; end
function onEdit_trrb_value_unpress(val)  trrb_value_unpress = val;    return true; end

function onEdit_Deadzone(ded)
    gamepad_set_axis_deadzone(0, ded)
    deadZone = ded
    return true
end
onEdit_Deadzone(0.1)

function init()
    -- This function runs once the add-on is activated.
    s_controller           = sprite_add("./img/controller outline.png",   2, false, false, 240,  0)
    s_controller_knob      = sprite_add("./img/controller knob.png",      2, false, false,  16, 16)
    s_controller_arrow     = sprite_add("./img/controller arrow.png",     4, false, false,  32, 32)
    s_controller_button    = sprite_add("./img/controller button.png",    4, false, false,  16, 16)
    s_controller_trigger   = sprite_add("./img/controller trigger.png",   2, false, false, 100, 40)
    s_controller_dpad_axis = sprite_add("./img/controller dpad axis.png", 2, false, false,  16, 16)
    s_animation_control    = sprite_add("./img/animation control.png",    3, false, false,  12, 12)

    tb_lana_Center = VectorBox.new(2, "onEdit_lana_Center")
    tb_lana_Scale  = TextBox.new(tb_number, "onEdit_lana_Scale")
    tb_rana_Center = VectorBox.new(2, "onEdit_rana_Center")
    tb_rana_Scale  = TextBox.new(tb_number, "onEdit_rana_Scale")
    tbDead         = TextBox.new(tb_number, "onEdit_Deadzone")

    tb_btx_value_press   = TextBox.new(tb_number, "onEdit_btx_value_press")
    tb_bty_value_press   = TextBox.new(tb_number, "onEdit_bty_value_press")
    tb_bta_value_press   = TextBox.new(tb_number, "onEdit_bta_value_press")
    tb_btb_value_press   = TextBox.new(tb_number, "onEdit_btb_value_press")
    
    tb_btx_value_unpress   = TextBox.new(tb_number, "onEdit_btx_value_unpress")
    tb_bty_value_unpress   = TextBox.new(tb_number, "onEdit_bty_value_unpress")
    tb_bta_value_unpress   = TextBox.new(tb_number, "onEdit_bta_value_unpress")
    tb_btb_value_unpress   = TextBox.new(tb_number, "onEdit_btb_value_unpress")

    tb_pdh_value   = VectorBox.new(2, "onEdit_pdh_value")
    tb_pdv_value   = VectorBox.new(2, "onEdit_pdv_value")

    tb_trl_value_press   = TextBox.new(tb_number, "onEdit_trl_value_press")
    tb_trlb_value_press  = TextBox.new(tb_number, "onEdit_trlb_value_press")
    tb_trr_value_press   = TextBox.new(tb_number, "onEdit_trr_value_press")
    tb_trrb_value_press  = TextBox.new(tb_number, "onEdit_trrb_value_press")
    
    tb_trl_value_unpress   = TextBox.new(tb_number, "onEdit_trl_value_unpress")
    tb_trlb_value_unpress  = TextBox.new(tb_number, "onEdit_trlb_value_unpress")
    tb_trr_value_unpress   = TextBox.new(tb_number, "onEdit_trr_value_unpress")
    tb_trrb_value_unpress  = TextBox.new(tb_number, "onEdit_trrb_value_unpress")
end

function step()
    -- This function runs every program step.

    if(lana_node ~= "" and lana_valueKey ~= "") then
        haxis = gamepad_axis_value(0, gp_axislh);
        vaxis = gamepad_axis_value(0, gp_axislv);

        val = { lana_center[1] + haxis * lana_scale, lana_center[2] + vaxis * lana_scale }
        node_set_input_value(lana_node, lana_valueKey, val)
    end

    if(rana_node ~= "" and rana_valueKey ~= "") then
        haxis = gamepad_axis_value(0, gp_axisrh);
        vaxis = gamepad_axis_value(0, gp_axisrv);

        val = { rana_center[1] + haxis * rana_scale, rana_center[2] + vaxis * rana_scale }
        node_set_input_value(rana_node, rana_valueKey, val)
    end

    if(btx_node ~= "" and btx_valueKey ~= "") then
        val = gamepad_button_value(0, gp_face3);
        if(val == 1) then node_set_input_value(btx_node, btx_valueKey, btx_value_press)
        else              node_set_input_value(btx_node, btx_valueKey, btx_value_unpress)
        end
    end

    if(bty_node ~= "" and bty_valueKey ~= "") then
        val = gamepad_button_value(0, gp_face4);
        if(val == 1) then node_set_input_value(bty_node, bty_valueKey, bty_value_press)
        else              node_set_input_value(bty_node, bty_valueKey, bty_value_unpress)
        end
    end

    if(bta_node ~= "" and bta_valueKey ~= "") then
        val = gamepad_button_value(0, gp_face1);
        if(val == 1) then node_set_input_value(bta_node, bta_valueKey, bta_value_press)
        else              node_set_input_value(bta_node, bta_valueKey, bta_value_unpress)
        end
    end

    if(btb_node ~= "" and btb_valueKey ~= "") then
        val = gamepad_button_value(0, gp_face2);
        if(val == 1) then node_set_input_value(btb_node, btb_valueKey, btb_value_press)
        else              node_set_input_value(btb_node, btb_valueKey, btb_value_unpress)
        end
    end
    
    if(pdh_node ~= "" and pdh_valueKey ~= "") then
        if(gamepad_button_value(0, gp_padl) == 1) then 
            val = node_get_input_value(pdh_node, pdh_valueKey)
            node_set_input_value(pdh_node, pdh_valueKey, val + pdh_value[1])
        end

        if(gamepad_button_value(0, gp_padr) == 1) then 
            val = node_get_input_value(pdh_node, pdh_valueKey)
            node_set_input_value(pdh_node, pdh_valueKey, val + pdh_value[2])
        end
    end
    
    if(pdv_node ~= "" and pdv_valueKey ~= "") then
        if(gamepad_button_value(0, gp_padd) == 1) then 
            val = node_get_input_value(pdv_node, pdv_valueKey)
            node_set_input_value(pdv_node, pdv_valueKey, val + pdv_value[1])
        end

        if(gamepad_button_value(0, gp_padu) == 1) then 
            val = node_get_input_value(pdv_node, pdv_valueKey)
            node_set_input_value(pdv_node, pdv_valueKey, val + pdv_value[2])
        end
    end

    if(trl_node ~= "" and trl_valueKey ~= "") then
        val = gamepad_button_value(0, gp_shoulderl);
        if(val == 1) then node_set_input_value(trl_node, trl_valueKey, trl_value_press)
        else              node_set_input_value(trl_node, trl_valueKey, trl_value_unpress)
        end
    end

    if(trlb_node ~= "" and trlb_valueKey ~= "") then
        val = gamepad_button_value(0, gp_shoulderlb);
        node_set_input_value(trlb_node, trlb_valueKey, lerp(trlb_value_unpress, trlb_value_press, 1 - val))
    end

    if(trr_node ~= "" and trr_valueKey ~= "") then
        val = gamepad_button_value(0, gp_shoulderr);
        if(val == 1) then node_set_input_value(trr_node, trr_valueKey, trr_value_press)
        else              node_set_input_value(trr_node, trr_valueKey, trr_value_unpress)
        end
    end

    if(trrb_node ~= "" and trrb_valueKey ~= "") then
        val = gamepad_button_value(0, gp_shoulderrb);
        node_set_input_value(trrb_node, trrb_valueKey, lerp(trrb_value_unpress, trrb_value_press, 1 - val))
    end

end

function animationPreStep()
    -- This function runs every animation frame before node execution
end

function animationPostStep()
    -- This function runs every animation frame after node execution
end

function drawPad_analog()
    xc = Panel.w / 2;

    draw_set_color(color_icon)
    draw_line_round(xc - 116,  96, xc - 320,  96, 2)
    draw_line_round(xc +  71, 148, xc + 320, 148, 2)

    draw_text_set_format(4)
    lana_w = math.max(string_width(lana_node .. " " .. lana_valueKey) + 16, 64)
    lana_h = 24
    lana_x = xc - 320
    lana_y = 96 - 4 - lana_h

    rana_w = math.max(string_width(rana_node .. " " .. rana_valueKey) + 16, 64)
    rana_h = 24
    rana_x = xc + 320 - rana_w
    rana_y = 148 - 4 - rana_h

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], lana_x, lana_y, lana_x + lana_w, lana_y + lana_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, lana_x, lana_y, lana_w, lana_h, c_white, 1)
        if(not lana_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            lana_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, lana_x, lana_y, lana_w, lana_h, color_white, 1)
    end

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], rana_x, rana_y, rana_x + rana_w, rana_y + rana_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, rana_x, rana_y, rana_w, rana_h, c_white, 1)
        if(not rana_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            rana_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, rana_x, rana_y, rana_w, rana_h, color_white, 1)
    end

    draw_text_set_format(4)
    draw_set_halign(fa_left)
    draw_set_valign(fa_center)

    draw_set_color(color_text)
    draw_text(lana_x + 8, lana_y + lana_h / 2, lana_node)
    draw_text(rana_x + 8, rana_y + rana_h / 2, rana_node)

    draw_set_color(color_text_sub)
    draw_text(lana_x + 8 + string_width(lana_node .. " "), lana_y + lana_h / 2, lana_valueKey)
    draw_text(rana_x + 8 + string_width(rana_node .. " "), rana_y + rana_h / 2, rana_valueKey)
end

function drawPad_button(menu_y)
    xc = Panel.w / 2;

    bx = xc + 80
    draw_sprite_ext(s_controller_button, 0, bx, 72 + 48 * 0, 1, 1, 0, color_icon, 1)
    draw_sprite_ext(s_controller_button, 1, bx, 72 + 48 * 1, 1, 1, 0, color_icon, 1)
    draw_sprite_ext(s_controller_button, 2, bx, 72 + 48 * 2, 1, 1, 0, color_icon, 1)
    draw_sprite_ext(s_controller_button, 3, bx, 72 + 48 * 3, 1, 1, 0, color_icon, 1)

    draw_text_set_format(4)
    
    btx_w = math.max(string_width(btx_node .. " " .. btx_valueKey) + 16, 64)
    btx_h = 24
    btx_x = bx + 32
    btx_y = 72 + 48 * 0 - btx_h / 2

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], btx_x, btx_y, btx_x + btx_w, btx_y + btx_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, btx_x, btx_y, btx_w, btx_h, c_white, 1)
        if(not btx_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            btx_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, btx_x, btx_y, btx_w, btx_h, color_white, 1)
    end
    
    bty_w = math.max(string_width(bty_node .. " " .. bty_valueKey) + 16, 64)
    bty_h = 24
    bty_x = bx + 32
    bty_y = 72 + 48 * 1 - bty_h / 2

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], bty_x, bty_y, bty_x + bty_w, bty_y + bty_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, bty_x, bty_y, bty_w, bty_h, c_white, 1)
        if(not bty_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            bty_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, bty_x, bty_y, bty_w, bty_h, color_white, 1)
    end
    
    bta_w = math.max(string_width(bta_node .. " " .. bta_valueKey) + 16, 64)
    bta_h = 24
    bta_x = bx + 32
    bta_y = 72 + 48 * 2 - bta_h / 2

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], bta_x, bta_y, bta_x + bta_w, bta_y + bta_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, bta_x, bta_y, bta_w, bta_h, c_white, 1)
        if(not bta_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            bta_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, bta_x, bta_y, bta_w, bta_h, color_white, 1)
    end
    
    btb_w = math.max(string_width(btb_node .. " " .. btb_valueKey) + 16, 64)
    btb_h = 24
    btb_x = bx + 32
    btb_y = 72 + 48 * 3 - btb_h / 2

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], btb_x, btb_y, btb_x + btb_w, btb_y + btb_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, btb_x, btb_y, btb_w, btb_h, c_white, 1)
        if(not btb_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            btb_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, btb_x, btb_y, btb_w, btb_h, color_white, 1)
    end
    
    draw_text_set_format(4)
    draw_set_halign(fa_left)
    draw_set_valign(fa_center)

    draw_set_color(color_text)
    draw_text(btx_x + 8, btx_y + btx_h / 2, btx_node)
    draw_text(bty_x + 8, bty_y + bty_h / 2, bty_node)
    draw_text(bta_x + 8, bta_y + bta_h / 2, bta_node)
    draw_text(btb_x + 8, btb_y + btb_h / 2, btb_node)

    draw_set_color(color_text_sub)
    draw_text(btx_x + 8 + string_width(btx_node .. " "), btx_y + btx_h / 2, btx_valueKey)
    draw_text(bty_x + 8 + string_width(bty_node .. " "), bty_y + bty_h / 2, bty_valueKey)
    draw_text(bta_x + 8 + string_width(bta_node .. " "), bta_y + bta_h / 2, bta_valueKey)
    draw_text(btb_x + 8 + string_width(btb_node .. " "), btb_y + btb_h / 2, btb_valueKey)
end

function drawPad_dpad(menu_y)
    xc = Panel.w / 2;

    bx = xc + 80
    draw_sprite_ext(s_controller_dpad_axis, 0, bx, 72 + 48 * 1, 1, 1, 0, color_icon, 1)
    draw_sprite_ext(s_controller_dpad_axis, 1, bx, 72 + 48 * 2, 1, 1, 0, color_icon, 1)

    draw_text_set_format(4)
    
    pdh_w = math.max(string_width(pdh_node .. " " .. pdh_valueKey) + 16, 64)
    pdh_h = 24
    pdh_x = bx + 32
    pdh_y = 72 + 48 * 1 - pdh_h / 2

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], pdh_x, pdh_y, pdh_x + pdh_w, pdh_y + pdh_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, pdh_x, pdh_y, pdh_w, pdh_h, c_white, 1)
        if(not pdh_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            pdh_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, pdh_x, pdh_y, pdh_w, pdh_h, color_white, 1)
    end
    
    pdv_w = math.max(string_width(pdv_node .. " " .. pdv_valueKey) + 16, 64)
    pdv_h = 24
    pdv_x = bx + 32
    pdv_y = 72 + 48 * 2 - pdv_h / 2

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], pdv_x, pdv_y, pdv_x + pdv_w, pdv_y + pdv_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, pdv_x, pdv_y, pdv_w, pdv_h, c_white, 1)
        if(not pdv_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            pdv_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, pdv_x, pdv_y, pdv_w, pdv_h, color_white, 1)
    end
    
    draw_text_set_format(4)
    draw_set_halign(fa_left)
    draw_set_valign(fa_center)

    draw_set_color(color_text)
    draw_text(pdh_x + 8, pdh_y + pdh_h / 2, pdh_node)
    draw_text(pdv_x + 8, pdv_y + pdv_h / 2, pdv_node)

    draw_set_color(color_text_sub)
    draw_text(pdh_x + 8 + string_width(pdh_node .. " "), pdh_y + pdh_h / 2, pdh_valueKey)
    draw_text(pdv_x + 8 + string_width(pdv_node .. " "), pdv_y + pdv_h / 2, pdv_valueKey)
end

function drawPad_trigger(menu_y)
    xc = Panel.w / 2;

    draw_set_color(color_icon)
    draw_line_round(xc + 116,  96, xc + 320,  96, 2)
    draw_line_round(xc - 116,  96, xc - 320,  96, 2)

    draw_line_round(xc + 132, 160, xc + 320, 160, 2)
    draw_line_round(xc - 132, 160, xc - 320, 160, 2)

    trl_w = math.max(string_width(trl_node .. " " .. trl_valueKey) + 16, 64)
    trl_h = 24
    trl_x = xc - 320
    trl_y = 96 - 4 - trl_h

    draw_text_set_format(4)

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], trl_x, trl_y, trl_x + trl_w, trl_y + trl_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trl_x, trl_y, trl_w, trl_h, c_white, 1)
        if(not trl_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            trl_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trl_x, trl_y, trl_w, trl_h, color_white, 1)
    end
    
    trlb_w = math.max(string_width(trlb_node .. " " .. trlb_valueKey) + 16, 64)
    trlb_h = 24
    trlb_x = xc - 320
    trlb_y = 160 - 4 - trlb_h

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], trlb_x, trlb_y, trlb_x + trlb_w, trlb_y + trlb_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trlb_x, trlb_y, trlb_w, trlb_h, c_white, 1)
        if(not trlb_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            trlb_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trlb_x, trlb_y, trlb_w, trlb_h, color_white, 1)
    end
    
    trr_w = math.max(string_width(trr_node .. " " .. trr_valueKey) + 16, 64)
    trr_h = 24
    trr_x = xc + 320 - trr_w
    trr_y = 96 - 4 - trr_h

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], trr_x, trr_y, trr_x + trr_w, trr_y + trr_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trr_x, trr_y, trr_w, trr_h, c_white, 1)
        if(not trr_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            trr_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trr_x, trr_y, trr_w, trr_h, color_white, 1)
    end
    
    trrb_w = math.max(string_width(trrb_node .. " " .. trrb_valueKey) + 16, 64)
    trrb_h = 24
    trrb_x = xc + 320 - trrb_w
    trrb_y = 160 - 4 - trrb_h

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], trrb_x, trrb_y, trrb_x + trrb_w, trrb_y + trrb_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trrb_x, trrb_y, trrb_w, trrb_h, c_white, 1)
        if(not trrb_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            trrb_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, trrb_x, trrb_y, trrb_w, trrb_h, color_white, 1)
    end
    
    draw_set_halign(fa_left)
    draw_set_valign(fa_center)

    draw_set_color(color_text)
    draw_text(trl_x + 8, trl_y + trl_h / 2, trl_node)
    draw_text(trlb_x + 8, trlb_y + trlb_h / 2, trlb_node)
    draw_text(trr_x + 8, trr_y + trr_h / 2, trr_node)
    draw_text(trrb_x + 8, trrb_y + trrb_h / 2, trrb_node)

    draw_set_color(color_text_sub)
    draw_text(trl_x + 8 + string_width(trl_node .. " "), trl_y + trl_h / 2, trl_valueKey)
    draw_text(trlb_x + 8 + string_width(trlb_node .. " "), trlb_y + trlb_h / 2, trlb_valueKey)
    draw_text(trr_x + 8 + string_width(trr_node .. " "), trr_y + trr_h / 2, trr_valueKey)
    draw_text(trrb_x + 8 + string_width(trrb_node .. " "), trrb_y + trrb_h / 2, trrb_valueKey)
end

function drawPad()
    l_haxis = gamepad_axis_value(0, gp_axislh);
    l_vaxis = gamepad_axis_value(0, gp_axislv);
    r_haxis = gamepad_axis_value(0, gp_axisrh);
    r_vaxis = gamepad_axis_value(0, gp_axisrv);

    l_active = math.sqrt(l_haxis * l_haxis + l_vaxis * l_vaxis) >= deadZone
    r_active = math.sqrt(r_haxis * r_haxis + r_vaxis * r_vaxis) >= deadZone

    l_c = color_icon
    r_c = color_icon

    ctr_cx = Panel.w / 2
    
    if(setting_page == 1) then
        ctr_cx = ctr_cx - 160 
    elseif(setting_page == 2) then
        ctr_cx = ctr_cx - 160
    end

    ctr_x = ctr_cx - 240

    l_knx = ctr_x + 150.5
    l_kny = 94.5

    r_knx = ctr_x + 286
    r_kny = 148.5

    if(l_active) then
        l_c = c_white
        l_knx = l_knx + l_haxis * 20
        l_kny = l_kny + l_vaxis * 20
    end

    if(r_active) then
        r_c = c_white
        r_knx = r_knx + r_haxis * 20
        r_kny = r_kny + r_vaxis * 20
    end

    ar_u = gamepad_button_check(0, gp_padu) == 1
    ar_l = gamepad_button_check(0, gp_padl) == 1
    ar_d = gamepad_button_check(0, gp_padd) == 1
    ar_r = gamepad_button_check(0, gp_padr) == 1

    bt_x = gamepad_button_check(0, gp_face3) == 1
    bt_y = gamepad_button_check(0, gp_face4) == 1
    bt_a = gamepad_button_check(0, gp_face1) == 1
    bt_b = gamepad_button_check(0, gp_face2) == 1

    ar_u_c = color_icon
    ar_l_c = color_icon
    ar_d_c = color_icon
    ar_r_c = color_icon

    bt_x_c = color_icon
    bt_y_c = color_icon
    bt_a_c = color_icon
    bt_b_c = color_icon

    if(ar_u) then ar_u_c = c_white end
    if(ar_l) then ar_l_c = c_white end
    if(ar_d) then ar_d_c = c_white end
    if(ar_r) then ar_r_c = c_white end
    if(bt_x) then bt_x_c = c_white end
    if(bt_y) then bt_y_c = c_white end
    if(bt_a) then bt_a_c = c_white end
    if(bt_b) then bt_b_c = c_white end
    
    draw_sprite_ext(s_controller_arrow, 0, ctr_x + 193.4, 152.15, 1, 1, 0, ar_u_c, 1)
    draw_sprite_ext(s_controller_arrow, 1, ctr_x + 193.4, 152.15, 1, 1, 0, ar_l_c, 1)
    draw_sprite_ext(s_controller_arrow, 2, ctr_x + 193.4, 152.15, 1, 1, 0, ar_d_c, 1)
    draw_sprite_ext(s_controller_arrow, 3, ctr_x + 193.4, 152.15, 1, 1, 0, ar_r_c, 1)

    draw_sprite_ext(s_controller_button, 0, ctr_x + 305.5,  95.5, 1, 1, 0, bt_x_c, 1)
    draw_sprite_ext(s_controller_button, 1, ctr_x + 329.5,  71.5, 1, 1, 0, bt_y_c, 1)
    draw_sprite_ext(s_controller_button, 2, ctr_x + 329.5, 119.5, 1, 1, 0, bt_a_c, 1)
    draw_sprite_ext(s_controller_button, 3, ctr_x + 355.0,  95.5, 1, 1, 0, bt_b_c, 1)

    draw_sprite_ext(s_controller, 0, ctr_cx, 0, 1, 1, 0, color_icon, 1)

    draw_sprite_ext(s_controller_knob, 0, l_knx, l_kny, 1, 1, 0, color_dkgrey, 1)
    draw_sprite_ext(s_controller_knob, 0, r_knx, r_kny, 1, 1, 0, color_dkgrey, 1)

    draw_sprite_ext(s_controller_knob, 1, l_knx, l_kny, 1, 1, 0, l_c, 1)
    draw_sprite_ext(s_controller_knob, 1, r_knx, r_kny, 1, 1, 0, r_c, 1)

    if(setting_page == 0) then
        drawPad_analog()
    elseif(setting_page == 1) then
        drawPad_button()
    elseif(setting_page == 2) then
        drawPad_dpad()
    end
end

function drawPadTop()
    sh_l  = gamepad_button_check(0, gp_shoulderr) == 1
    sh_lb = gamepad_button_check(0, gp_shoulderrb) == 1
    sh_r  = gamepad_button_check(0, gp_shoulderl) == 1
    sh_rb = gamepad_button_check(0, gp_shoulderlb) == 1

    sh_l_c  = color_icon
    sh_lb_c = color_icon
    sh_r_c  = color_icon
    sh_rb_c = color_icon

    if(sh_l)  then sh_l_c  = c_white end
    if(sh_lb) then sh_lb_c = c_white end
    if(sh_r)  then sh_r_c  = c_white end
    if(sh_rb) then sh_rb_c = c_white end

    ctr_x = Panel.w / 2

    draw_sprite_ext(s_controller_trigger, 0, ctr_x + 130.0, 106.0, 1, 1, 0, sh_l_c, 1)
    draw_sprite_ext(s_controller_trigger, 1, ctr_x + 156.0, 145.5, 1, 1, 0, sh_lb_c, 1)

    draw_sprite_ext(s_controller_trigger, 0, ctr_x - 130.0, 106.0, -1, 1, 0, sh_r_c, 1)
    draw_sprite_ext(s_controller_trigger, 1, ctr_x - 156.0, 145.5, -1, 1, 0, sh_rb_c, 1)

    draw_sprite_ext(s_controller, 1, Panel.w / 2, 0, 1, 1, 0, color_icon, 1)

    draw_set_halign(fa_center)
    draw_set_valign(fa_center)

    draw_set_color(color_text_sub)
    draw_text(Panel.w / 2, 200, "Mirrored")

    drawPad_trigger()
end

function drawSettings_analog(menu_y)
    xc = Panel.w / 2;

    draw_set_color(color_icon_dark)
    draw_roundrect_ext(     8, menu_y - 20,      xc - 4, menu_y + 8 + 40 * 2, 4, 4, true)
    draw_roundrect_ext(xc + 4, menu_y - 20, Panel.w - 8, menu_y + 8 + 40 * 2, 4, 4, true)

    draw_text_set_format(3)
    draw_set_halign(fa_left)
    draw_set_valign(fa_top)
    draw_text(     16, menu_y - 20 + 2, "Left analog")
    draw_text(xc + 12, menu_y - 20 + 2, "Right analog")

    draw_set_valign(fa_center)
    draw_text_set_format(1)
    draw_text(     16, menu_y + 8 + 40 * 0 + 16, "Offset")
    draw_text(     16, menu_y + 8 + 40 * 1 + 16, "Scale")
    draw_text(xc + 12, menu_y + 8 + 40 * 0 + 16, "Offset")
    draw_text(xc + 12, menu_y + 8 + 40 * 1 + 16, "Scale")

    draw_text(     16, menu_y + 20 + 40 * 2 + 16, "Deadzone")

    tb_lana_Center.draw(tb_lana_Center,          100, menu_y + 8 + 40 * 0, xc - 10 - 100, 32, lana_center)
    tb_lana_Scale.draw(tb_lana_Scale,            100, menu_y + 8 + 40 * 1, xc - 10 - 100, 32, lana_scale)

    tb_rana_Center.draw(tb_rana_Center, xc + 100 - 4, menu_y + 8 + 40 * 0, xc - 10 - 100, 32, rana_center)
    tb_rana_Scale.draw(tb_rana_Scale,   xc + 100 - 4, menu_y + 8 + 40 * 1, xc - 10 - 100, 32, rana_scale)

    tbDead.draw(tbDead,     100, menu_y + 20 + 40 * 2, Panel.w - 8 - 100, 32, deadZone)
end

function drawSettings_button(menu_y)
    x0 = Panel.w / 4 * 1;
    x1 = Panel.w / 4 * 2;
    x2 = Panel.w / 4 * 3;
    x3 = Panel.w / 4 * 4;

    draw_set_color(color_icon_dark)
    draw_roundrect_ext(      8, menu_y - 20, x0 - 4, menu_y + 88, 4, 4, true)
    draw_roundrect_ext( x0 + 4, menu_y - 20, x1 - 4, menu_y + 88, 4, 4, true)
    draw_roundrect_ext( x1 + 4, menu_y - 20, x2 - 4, menu_y + 88, 4, 4, true)
    draw_roundrect_ext( x2 + 4, menu_y - 20, x3 - 8, menu_y + 88, 4, 4, true)

    draw_text_set_format(3)
    draw_set_halign(fa_left)
    draw_set_valign(fa_top)
    draw_text(      8 + 8, menu_y - 20 + 2, "X button")
    draw_text( x0 + 4 + 8, menu_y - 20 + 2, "Y button")
    draw_text( x1 + 4 + 8, menu_y - 20 + 2, "A button")
    draw_text( x2 + 4 + 8, menu_y - 20 + 2, "B button")

    draw_set_valign(fa_center)
    draw_text_set_format(1)
    draw_text(      8 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text(      8 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")
    draw_text( x0 + 4 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text( x0 + 4 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")
    draw_text( x1 + 4 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text( x1 + 4 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")
    draw_text( x2 + 4 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text( x2 + 4 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")

    tb_btx_value_press.draw(    tb_btx_value_press, 8 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   btx_value_press)
    tb_btx_value_unpress.draw(tb_btx_value_unpress, 8 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, btx_value_unpress)
    
    tb_bty_value_press.draw(    tb_bty_value_press, x0 + 4 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   bty_value_press)
    tb_bty_value_unpress.draw(tb_bty_value_unpress, x0 + 4 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, bty_value_unpress)
    
    tb_bta_value_press.draw(    tb_bta_value_press, x1 + 4 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   bta_value_press)
    tb_bta_value_unpress.draw(tb_bta_value_unpress, x1 + 4 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, bta_value_unpress)
    
    tb_btb_value_press.draw(    tb_btb_value_press, x2 + 4 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   btb_value_press)
    tb_btb_value_unpress.draw(tb_btb_value_unpress, x2 + 4 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, btb_value_unpress)
end

function drawSettings_dpad(menu_y)
    xc = Panel.w / 2;

    draw_set_color(color_icon_dark)
    draw_roundrect_ext(      8, menu_y - 20,      xc - 4, menu_y + 48, 4, 4, true)
    draw_roundrect_ext( xc + 4, menu_y - 20, Panel.w - 8, menu_y + 48, 4, 4, true)
    
    draw_text_set_format(3)
    draw_set_halign(fa_left)
    draw_set_valign(fa_top)
    draw_text(      8 + 8, menu_y - 20 + 2, "Horizontal")
    draw_text( xc + 4 + 8, menu_y - 20 + 2, "Vertical")

    draw_set_valign(fa_center)
    draw_text_set_format(1)
    draw_text(      8 + 8, menu_y + 8 + 40 * 0 + 16, "Increment")
    draw_text( xc + 4 + 8, menu_y + 8 + 40 * 0 + 16, "Increment")

    tb_pdh_value.draw(    tb_pdh_value,      8 + 100, menu_y + 8 + 40 * 0, xc - 16 - 100, 32, pdh_value)

    tb_pdv_value.draw(    tb_pdv_value, xc + 4 + 100, menu_y + 8 + 40 * 0, xc - 16 - 100, 32, pdv_value)
end

function drawSettings_trigger(menu_y)
    x0 = Panel.w / 4 * 1;
    x1 = Panel.w / 4 * 2;
    x2 = Panel.w / 4 * 3;
    x3 = Panel.w / 4 * 4;

    draw_set_color(color_icon_dark)
    draw_roundrect_ext(      8, menu_y - 20, x0 - 4, menu_y + 88, 4, 4, true)
    draw_roundrect_ext( x0 + 4, menu_y - 20, x1 - 4, menu_y + 88, 4, 4, true)
    draw_roundrect_ext( x1 + 4, menu_y - 20, x2 - 4, menu_y + 88, 4, 4, true)
    draw_roundrect_ext( x2 + 4, menu_y - 20, x3 - 8, menu_y + 88, 4, 4, true)
    
    draw_text_set_format(3)
    draw_set_halign(fa_left)
    draw_set_valign(fa_top)
    draw_text(      8 + 8, menu_y - 20 + 2, "Left trigger")
    draw_text( x0 + 4 + 8, menu_y - 20 + 2, "Left back trigger")
    draw_text( x1 + 4 + 8, menu_y - 20 + 2, "Right trigger")
    draw_text( x2 + 4 + 8, menu_y - 20 + 2, "Right back trigger")

    draw_set_valign(fa_center)
    draw_text_set_format(1)
    draw_text(      8 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text(      8 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")
    draw_text( x0 + 4 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text( x0 + 4 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")
    draw_text( x1 + 4 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text( x1 + 4 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")
    draw_text( x2 + 4 + 8, menu_y + 8 + 40 * 0 + 16, "Unpressed")
    draw_text( x2 + 4 + 8, menu_y + 8 + 40 * 1 + 16, "Pressed")

    tb_trl_value_press.draw(    tb_trl_value_press, 8 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   trl_value_press)
    tb_trl_value_unpress.draw(tb_trl_value_unpress, 8 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, trl_value_unpress)
    
    tb_trlb_value_press.draw(    tb_trlb_value_press, x0 + 4 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   trlb_value_press)
    tb_trlb_value_unpress.draw(tb_trlb_value_unpress, x0 + 4 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, trlb_value_unpress)
    
    tb_trr_value_press.draw(    tb_trr_value_press, x1 + 4 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   trr_value_press)
    tb_trr_value_unpress.draw(tb_trr_value_unpress, x1 + 4 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, trr_value_unpress)
    
    tb_trrb_value_press.draw(    tb_trrb_value_press, x2 + 4 + 120, menu_y + 8 + 40 * 0, x0 - 16 - 120, 32,   trrb_value_press)
    tb_trrb_value_unpress.draw(tb_trrb_value_unpress, x2 + 4 + 120, menu_y + 8 + 40 * 1, x0 - 16 - 120, 32, trrb_value_unpress)
end

function drawSettings()
    xc = Panel.w / 2;
    menu_y = 320

    draw_text_set_format(1)
    draw_set_halign(fa_center)
    draw_set_valign(fa_center)
    draw_set_color(color_icon_light)

    menus = {"Analog", "Button", "D-Pad", "Trigger"}
    mn_sx = xc - (4 - 1) / 2 * 80

    for i = 0, 3 do
        mn_x = mn_sx + i * 80
        mn_y = menu_y + 0
        mn_w = string_width(menus[i + 1]) + 16
        mn_h = 32

        if(setting_page == i) then
            draw_sprite_stretched_ext(s_ui_panel_bg, 0, mn_x - mn_w / 2, mn_y - mn_h / 2, mn_w, mn_h, color_icon, 1)
            draw_set_color(color_icon_light)
        else
            if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], mn_x - mn_w / 2, mn_y - mn_h / 2, mn_x + mn_w / 2, mn_y + mn_h / 2) == 1) then
                draw_sprite_stretched_ext(s_ui_panel_bg, 0, mn_x - mn_w / 2, mn_y - mn_h / 2, mn_w, mn_h, c_white, 1)
                if(mouse_check_button_pressed(mb_left) == 1) then
                    setting_page = i
                end
            end
            draw_set_color(color_icon)
        end

        draw_text(mn_x, mn_y, menus[i + 1])
    end

    _menu_y = menu_y + 48

    if(setting_page == 0) then
        drawSettings_analog(_menu_y)
    elseif(setting_page == 1) then
        drawSettings_button(_menu_y)
    elseif(setting_page == 2) then
        drawSettings_dpad(_menu_y)
    elseif(setting_page == 3) then
        drawSettings_trigger(_menu_y)
    end
end

function drawControl()
    if(record_loop and not animation_playing()) then
        recording = false
        record_loop = false
    end

    bx = Panel.w - 8 - 16
    by = 8 + 16

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], bx - 16, by - 16, bx + 16, by + 16) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, bx - 16, by - 16, 32, 32, c_white, 1)
        if recording then 
            set_tooltip("Recording") 
        else 
            set_tooltip("Record")
        end

        if(mouse_check_button_pressed(mb_left) == 1) then
            recording = not recording
        end
    end
    
    c = color_icon_dark
    if recording then c = color_negative end
    draw_sprite_ext(s_animation_control, 2, bx, by, 1, 1, 0, c, 1)

    bx = bx - (32 + 4)

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], bx - 16, by - 16, bx + 16, by + 16) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, bx - 16, by - 16, 32, 32, c_white, 1)
        set_tooltip("Play animation once and record")

        if(mouse_check_button_pressed(mb_left) == 1) then
            animation_render()
            recording = true
            record_loop = true
        end
    end

    i = 0
    c = color_positive
    if record_loop then 
        i = 1 
        c = color_icon
    end
    
    draw_sprite_ext(s_animation_control, i, bx, by, 1, 1, 0, c, 1)
end

function draw()
    -- Use this function to draw the UI element in the panel.
    -- The coordinate in this function is relative to the panel.

    if(setting_page < 3) then
        drawPad()
    else
        drawPadTop()
    end

    drawSettings()
    drawControl()
end

function drawUI()
    -- Use this function to draw the UI element anywhere on the program.
    -- The coordinate in this function is relative to the program window.

    if lana_drag or rana_drag or btx_drag or bty_drag or bta_drag or btb_drag or pdh_drag or pdv_drag or trl_drag or trlb_drag or trr_drag or trrb_drag then
        draw_set_color(color_white)
        draw_line_round(drag_sx, drag_sy, Panel.mouseUI[1], Panel.mouseUI[2], 2)
    else 
        return
    end
    
    if mouse_check_button_released(mb_left) == 0 then
        return
    end

    _key  = element_get("internalName")
    _node = element_get("node", "internalName")

    if lana_drag then
        if(_key ~= nil and _node ~= nil) then
            lana_valueKey = _key
            lana_node = _node
        end

        lana_drag = false
    end

    if rana_drag then
        if(_key ~= nil and _node ~= nil) then
            rana_valueKey = _key
            rana_node = _node
        end

        rana_drag = false
    end

    if btx_drag then
        if(_key ~= nil and _node ~= nil) then
            btx_valueKey = _key
            btx_node = _node
        end

        btx_drag = false
    end

    if bty_drag then
        if(_key ~= nil and _node ~= nil) then
            bty_valueKey = _key
            bty_node = _node
        end

        bty_drag = false
    end

    if bta_drag then
        if(_key ~= nil and _node ~= nil) then
            bta_valueKey = _key
            bta_node = _node
        end

        bta_drag = false
    end

    if btb_drag then
        if(_key ~= nil and _node ~= nil) then
            btb_valueKey = _key
            btb_node = _node
        end

        btb_drag = false
    end

    if pdh_drag then
        if(_key ~= nil and _node ~= nil) then
            pdh_valueKey = _key
            pdh_node = _node
        end

        pdh_drag = false
    end

    if pdv_drag then
        if(_key ~= nil and _node ~= nil) then
            pdv_valueKey = _key
            pdv_node = _node
        end

        pdv_drag = false
    end

    if trl_drag then
        if(_key ~= nil and _node ~= nil) then
            trl_valueKey = _key
            trl_node = _node
        end

        trl_drag = false
    end

    if trlb_drag then
        if(_key ~= nil and _node ~= nil) then
            trlb_valueKey = _key
            trlb_node = _node
        end

        trlb_drag = false
    end

    if trr_drag then
        if(_key ~= nil and _node ~= nil) then
            trr_valueKey = _key
            trr_node = _node
        end

        trr_drag = false
    end

    if trrb_drag then
        if(_key ~= nil and _node ~= nil) then
            trrb_valueKey = _key
            trrb_node = _node
        end

        trrb_drag = false
    end
end

function closePanel()
    node = ""
    valueKey = ""
end

function destroy()
    -- This function is call when the addon is destroyed (close dialog, close program)
end

function setValue_lana(_data)
    lana_valueKey = _data.internalName
    lana_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_rana(_data)
    rana_valueKey = _data.internalName
    rana_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_btx(_data)
    btx_valueKey = _data.internalName
    btx_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_bty(_data)
    bty_valueKey = _data.internalName
    bty_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_bta(_data)
    bta_valueKey = _data.internalName
    bta_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_btb(_data)
    btb_valueKey = _data.internalName
    btb_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_pdh(_data)
    pdh_valueKey = _data.internalName
    pdh_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_pdv(_data)
    pdv_valueKey = _data.internalName
    pdv_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_trl(_data)
    trl_valueKey = _data.internalName
    trl_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_trlb(_data)
    trlb_valueKey = _data.internalName
    trlb_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_trr(_data)
    trr_valueKey = _data.internalName
    trr_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_trrb(_data)
    trrb_valueKey = _data.internalName
    trrb_node = _data.node.internalName

    panel_create("panel_controller")
end

function node_value_inspector_callback()
    return {
        { name = "Map to controller", content = {
            { name = "Left analog stick", callback = "setValue_lana" },
            { name = "Right analog stick", callback = "setValue_rana" },
            -1, 
            { name = "X button", callback = "setValue_btx" },
            { name = "Y button", callback = "setValue_bty" },
            { name = "A button", callback = "setValue_bta" },
            { name = "B button", callback = "setValue_btb" },
            -1, 
            { name = "Horizontal D pad", callback = "setValue_pdh" },
            { name = "Vertical D pad", callback = "setValue_pdv" },
            -1,
            { name = "Left trigger", callback = "setValue_trl" },
            { name = "Left back trigger", callback = "setValue_trlb" },
            { name = "Right trigger", callback = "setValue_trr" },
            { name = "Right back trigger", callback = "setValue_trrb" },
        }}
    }
end

function serialize()
    -- This function is call when the project is saved.
    -- The value is append to the project file.

    return {
        lana_node = lana_node,  lana_valueKey = lana_valueKey,  lana_center = lana_center,  lana_scale  = lana_scale,
        rana_node = rana_node,  rana_valueKey = rana_valueKey,  rana_center = rana_center,  rana_scale  = rana_scale,

        btx_node = btx_node,  btx_valueKey = btx_valueKey,  btx_value_press = btx_value_press,  btx_value_unpress = btx_value_unpress, 
        bty_node = bty_node,  bty_valueKey = bty_valueKey,  bty_value_press = bty_value_press,  bty_value_unpress = bty_value_unpress, 
        bta_node = bta_node,  bta_valueKey = bta_valueKey,  bta_value_press = bta_value_press,  bta_value_unpress = bta_value_unpress, 
        btb_node = btb_node,  btb_valueKey = btb_valueKey,  btb_value_press = btb_value_press,  btb_value_unpress = btb_value_unpress, 

        pdh_node = pdh_node,  pdh_valueKey = pdh_valueKey,  pdh_value = pdh_value, 
        pdv_node = pdv_node,  pdv_valueKey = pdv_valueKey,  pdv_value = pdv_value, 

        trl_node  = trl_node,   trl_valueKey  = trl_valueKey,   trl_value_press  = trl_value_press,   trl_value_unpress  = trl_value_unpress, 
        trlb_node = trlb_node,  trlb_valueKey = trlb_valueKey,  trlb_value_press = trlb_value_press,  trlb_value_unpress = trlb_value_unpress, 
        trr_node  = trr_node,   trr_valueKey  = trr_valueKey,   trr_value_press  = trr_value_press,   trr_value_unpress  = trr_value_unpress, 
        trrb_node = trrb_node,  trrb_valueKey = trrb_valueKey,  trrb_value_press = trrb_value_press,  trrb_value_unpress = trrb_value_unpress, 
    }
end

function deserialize(_data)
    -- This function is call when the project is loaded.
    -- 

    lana_node = _data.lana_node;  lana_valueKey = _data.lana_valueKey;  lana_center = _data.lana_center;            lana_scale  = _data.lana_scale;
    rana_node = _data.rana_node;  rana_valueKey = _data.rana_valueKey;  rana_center = _data.rana_center;            rana_scale  = _data.rana_scale;

    btx_node = _data.btx_node;    btx_valueKey = _data.btx_valueKey;    btx_value_press = _data.btx_value_press;    btx_value_unpress = _data.btx_value_unpress;
    bty_node = _data.bty_node;    bty_valueKey = _data.bty_valueKey;    bty_value_press = _data.bty_value_press;    bty_value_unpress = _data.bty_value_unpress;
    bta_node = _data.bta_node;    bta_valueKey = _data.bta_valueKey;    bta_value_press = _data.bta_value_press;    bta_value_unpress = _data.bta_value_unpress;
    btb_node = _data.btb_node;    btb_valueKey = _data.btb_valueKey;    btb_value_press = _data.btb_value_press;    btb_value_unpress = _data.btb_value_unpress;

    pdh_node = _data.pdh_node;    pdh_valueKey = _data.pdh_valueKey;    pdh_value = _data.pdh_value;
    pdv_node = _data.pdv_node;    pdv_valueKey = _data.pdv_valueKey;    pdv_value = _data.pdv_value;
    
    trl_node  = _data.trl_node;   trl_valueKey  = _data.trl_valueKey;   trl_value_press  = _data.trl_value_press;   trl_value_unpress  = _data.trl_value_unpress;
    trlb_node = _data.trlb_node;  trlb_valueKey = _data.trlb_valueKey;  trlb_value_press = _data.trlb_value_press;  trlb_value_unpress = _data.trlb_value_unpress;
    trr_node  = _data.trr_node;   trr_valueKey  = _data.trr_valueKey;   trr_value_press  = _data.trr_value_press;   trr_value_unpress  = _data.trr_value_unpress;
    trrb_node = _data.trrb_node;  trrb_valueKey = _data.trrb_valueKey;  trrb_value_press = _data.trrb_value_press;  trrb_value_unpress = _data.trrb_value_unpress;
end