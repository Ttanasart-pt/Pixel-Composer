lana_node = ""
lana_valueKey = ""
lana_center = { 0, 0 }
lana_scale  = 1
lana_drag = false

rana_node = ""
rana_valueKey = ""
rana_center = { 0, 0 }
rana_scale  = 1
rana_drag = false

drag_sx = 0
drag_sy = 0

deadZone = 0

function onEdit_lana_Center(i, cen)
    lana_center[i] = cen
    return true
end

function onEdit_lana_Scale(sca)
    lana_scale = sca
    return true
end

function onEdit_rana_Center(i, cen)
    rana_center[i] = cen
    return true
end

function onEdit_rana_Scale(sca)
    rana_scale = sca
    return true
end

function onEdit_Deadzone(ded)
    gamepad_set_axis_deadzone(0, ded)
    deadZone = ded
    return true
end

onEdit_Deadzone(0.1)

function init()
    -- This function runs once the add-on is activated.
    s_controller = sprite_add("./img/controller outline.png", 1, false, false, 240, 0)
    s_controller_knob = sprite_add("./img/controller knob.png", 2, false, false, 16, 16)

    tb_lana_Center = VectorBox.new(2, "onEdit_lana_Center")
    tb_lana_Scale  = TextBox.new(tb_number, "onEdit_lana_Scale")
    tb_rana_Center = VectorBox.new(2, "onEdit_rana_Center")
    tb_rana_Scale  = TextBox.new(tb_number, "onEdit_rana_Scale")

    tbDead   = TextBox.new(tb_number, "onEdit_Deadzone")
end

function step()
    -- This function runs every program step.
    if(lana_node ~= "" and lana_valueKey ~= "") then
        haxis = gamepad_axis_value(0, gp_axislh);
        vaxis = gamepad_axis_value(0, gp_axislv);

        val = { lana_center[1] + haxis * lana_scale, lana_center[2] + vaxis * lana_scale }
        node_set_input_value(lana_node, lana_valueKey, val) 
    end

    if(rana_node ~= "" and rana_valueKey ~= "") then
        haxis = gamepad_axis_value(0, gp_axisrh);
        vaxis = gamepad_axis_value(0, gp_axisrv);

        val = { rana_center[1] + haxis * rana_scale, rana_center[2] + vaxis * rana_scale }
        node_set_input_value(rana_node, rana_valueKey, val) 
    end
end

function animationPreStep()
    -- This function runs every animation frame before node execution
end

function animationPostStep()
    -- This function runs every animation frame after node execution
end

function draw()
    -- Use this function to draw the UI element in the panel.
    -- The coordinate in this function is relative to the panel.

    l_haxis = gamepad_axis_value(0, gp_axislh);
    l_vaxis = gamepad_axis_value(0, gp_axislv);
    r_haxis = gamepad_axis_value(0, gp_axisrh);
    r_vaxis = gamepad_axis_value(0, gp_axisrv);

    l_active = math.sqrt(l_haxis * l_haxis + l_vaxis * l_vaxis) >= deadZone
    r_active = math.sqrt(r_haxis * r_haxis + r_vaxis * r_vaxis) >= deadZone

    l_c = color_icon
    r_c = color_icon

    l_knx = Panel.w / 2 - 240 + 150.5
    l_kny = 94.5

    r_knx = Panel.w / 2 - 240 + 286
    r_kny = 148.5

    if(l_active) then
        l_c = c_white
        l_knx = l_knx + l_haxis * 20
        l_kny = l_kny + l_vaxis * 20
    end

    if(r_active) then
        r_c = c_white
        r_knx = r_knx + r_haxis * 20
        r_kny = r_kny + r_vaxis * 20
    end    

    draw_sprite_ext(s_controller, 0, Panel.w / 2, 0, 1, 1, 0, color_icon, 1)

    draw_set_color(color_icon)
    draw_line_round(Panel.w / 2 - 116,  96, Panel.w / 2 - 320,  96, 2)
    draw_line_round(Panel.w / 2 +  71, 148, Panel.w / 2 + 320, 148, 2)
    
    draw_sprite_ext(s_controller_knob, 0, l_knx, l_kny, 1, 1, 0, color_dkgrey, 1)
    draw_sprite_ext(s_controller_knob, 0, r_knx, r_kny, 1, 1, 0, color_dkgrey, 1)

    draw_sprite_ext(s_controller_knob, 1, l_knx, l_kny, 1, 1, 0, l_c, 1)
    draw_sprite_ext(s_controller_knob, 1, r_knx, r_kny, 1, 1, 0, r_c, 1)

    draw_text_set_format(4)
    lana_w = math.max(string_width(lana_node .. " " .. lana_valueKey) + 16, 64)
    lana_h = 24
    lana_x = Panel.w / 2 - 320
    lana_y = 96 - 4 - lana_h

    rana_w = math.max(string_width(rana_node .. " " .. rana_valueKey) + 16, 64)
    rana_h = 24
    rana_x = Panel.w / 2 + 320 - rana_w
    rana_y = 148 - 4 - rana_h

    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], lana_x, lana_y, lana_x + lana_w, lana_y + lana_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, lana_x, lana_y, lana_w, lana_h, c_white, 1)
        if(not lana_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            lana_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, lana_x, lana_y, lana_w, lana_h, color_white, 1)
    end
    
    if(point_in_rectangle(Panel.mouse[1], Panel.mouse[2], rana_x, rana_y, rana_x + rana_w, rana_y + rana_h) == 1) then
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, rana_x, rana_y, rana_w, rana_h, c_white, 1)
        if(not rana_drag and mouse_check_button_pressed(mb_left) == 1) then
            drag_sx = Panel.mouseUI[1]
            drag_sy = Panel.mouseUI[2]
            rana_drag = true
        end
    else
        draw_sprite_stretched_ext(s_ui_panel_bg, 0, rana_x, rana_y, rana_w, rana_h, color_white, 1)
    end

    draw_set_halign(fa_left)
    draw_set_valign(fa_center)

    draw_set_color(color_text)
    draw_text(lana_x + 8, lana_y + lana_h / 2, lana_node)
    draw_text(rana_x + 8, rana_y + rana_h / 2, rana_node)
    
    draw_set_color(color_text_sub)
    draw_text(lana_x + 8 + string_width(lana_node .. " "), lana_y + lana_h / 2, lana_valueKey)
    draw_text(rana_x + 8 + string_width(rana_node .. " "), rana_y + rana_h / 2, rana_valueKey)

    xc = Panel.w / 2;
    menu_y = 320

    draw_set_color(color_icon_dark)
    draw_roundrect_ext(     8, menu_y - 20,      xc - 4, menu_y + 40 * 2, 4, 4, true)
    draw_roundrect_ext(xc + 4, menu_y - 20, Panel.w - 8, menu_y + 40 * 2, 4, 4, true)

    draw_text_set_format(3);
    draw_set_halign(fa_left)
    draw_set_valign(fa_center)
    draw_text(     16, menu_y - 8, "Left analog");
    draw_text(xc + 12, menu_y - 8, "Right analog");

    draw_text_set_format(1);
    draw_text(     16, menu_y + 40 * 0 + 16, "Offset");
    draw_text(     16, menu_y + 40 * 1 + 16, "Scale");
    draw_text(xc + 12, menu_y + 40 * 0 + 16, "Offset");
    draw_text(xc + 12, menu_y + 40 * 1 + 16, "Scale");

    draw_text(     16, menu_y + 40 * 2.5 + 16, "Deadzone");

    tb_lana_Center.draw(tb_lana_Center,          100, menu_y + 40 * 0, xc - 10 - 100, 32, lana_center)
    tb_lana_Scale.draw(tb_lana_Scale,            100, menu_y + 40 * 1, xc - 10 - 100, 32, lana_scale)

    tb_rana_Center.draw(tb_rana_Center, xc + 100 - 4, menu_y + 40 * 0, xc - 10 - 100, 32, rana_center)
    tb_rana_Scale.draw(tb_rana_Scale,   xc + 100 - 4, menu_y + 40 * 1, xc - 10 - 100, 32, rana_scale)

    tbDead.draw(tbDead,     100, menu_y + 40 * 2.5, Panel.w - 8 - 100, 32, deadZone)
end

function drawUI()
    -- Use this function to draw the UI element anywhere on the program.
    -- The coordinate in this function is relative to the program window.
    
    if lana_drag then
        draw_set_color(color_white)
        draw_line_round(drag_sx, drag_sy, Panel.mouseUI[1], Panel.mouseUI[2], 2)

        if(mouse_check_button_released(mb_left) == 1) then
            _key  = element_get("internalName")
            _node = element_get("node", "internalName")

            if(_key ~= nil and _node ~= nil) then
                lana_valueKey = _key
                lana_node = _node
            end

            lana_drag = false
        end
    end
    
    if rana_drag then
        draw_set_color(color_white)
        draw_line_round(drag_sx, drag_sy, Panel.mouseUI[1], Panel.mouseUI[2], 2)

        if(mouse_check_button_released(mb_left) == 1) then
            _key  = element_get("internalName")
            _node = element_get("node", "internalName")

            if(_key ~= nil and _node ~= nil) then
                rana_valueKey = _key
                rana_node = _node
            end

            rana_drag = false
        end
    end
end

function closePanel()
    node = ""
    valueKey = ""
end

function destroy()
    -- This function is call when the addon is destroyed (close dialog, close program)
end

function setValue_lana(_data)
    lana_valueKey = _data.internalName
    lana_node = _data.node.internalName

    panel_create("panel_controller")
end

function setValue_rana(_data)
    rana_valueKey = _data.internalName
    rana_node = _data.node.internalName

    panel_create("panel_controller")
end

function node_value_inspector_callback()
    return { 
        { name = "Map to controller", content = {
            { name = "Left analog stick", callback = "setValue_lana" },
            { name = "Right analog stick", callback = "setValue_rana" },
        }}
    }
end